# 📷 Relatório de Projetos - Processamento Digital de Imagens (PDI)

Este repositório contém três projetos desenvolvidos para a disciplina de **Processamento Digital de Imagens (PDI)** do curso de **Ciência da Computação**. Os projetos utilizam a biblioteca OpenCV em Python para aplicar técnicas clássicas de segmentação e análise de imagens.

## 🛠️ Requisitos

- Python 3.7 ou superior
- OpenCV
- NumPy

### Instalação das dependências:

```bash
pip install opencv-python numpy
```

## 📁 Projetos

### 1. 🟩 Chroma Key (Remoção de Fundo Verde)

**Descrição:** Substituição de um fundo verde em uma imagem por outro plano de fundo escolhido.

📄 Código: `chroma_key.py`  
📷 Entrada: `img_fundo_verde_1.jpg`, `novo_background.jpg`  
💾 Saída: `resultado_chroma.jpg`

### 2. 🔵 Detecção de Círculos

**Descrição:** Detecção automática de círculos em uma imagem utilizando a Transformada de Hough.

📄 Código: `deteccao_circulos.py`  
📷 Entrada: `circulos_1.png`  
💾 Saída: `resultado_circulos.jpg`

### 3. 🍃 Detecção de Folhas Saudáveis e Danificadas

**Descrição:** Segmentação de folhas com base na cor para identificar regiões saudáveis (verde) e danificadas (amareladas ou marrons).

📄 Código: `deteccao_folhas.py`  
📷 Entrada: `img_folha_1.jpg`  
💾 Saída: `resultado_folha.jpg`

## 🚀 Como executar

Execute qualquer um dos projetos com:

```bash
python nome_do_script.py
```

**Exemplo:**

```bash
python chroma_key.py
```

Certifique-se de que as imagens de entrada estejam na mesma pasta dos scripts ou ajuste os caminhos conforme necessário.

## 👨‍💻 Autor

- **Victor Manuel**  
- Matrícula: 2214663  
- Curso: Ciência da Computação  

## 📄 Licença

Este projeto está disponível sob a licença MIT. Sinta-se livre para utilizar e modificar.